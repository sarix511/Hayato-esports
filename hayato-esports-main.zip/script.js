function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  firebase.auth().signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      document.getElementById("status").innerText = "Login successful!";
    })
    .catch((error) => {
      document.getElementById("status").innerText = error.message;
    });
}